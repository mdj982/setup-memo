﻿// C++/WinRT v1.0.180821.2

// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

#pragma once
#include "winrt/impl/Windows.Foundation.0.h"
#include "winrt/impl/Windows.Devices.I2c.Provider.0.h"

WINRT_EXPORT namespace winrt::Windows::Devices::I2c::Provider {

struct WINRT_EBO II2cControllerProvider :
    Windows::Foundation::IInspectable,
    impl::consume_t<II2cControllerProvider>
{
    II2cControllerProvider(std::nullptr_t = nullptr) noexcept {}
};

struct WINRT_EBO II2cDeviceProvider :
    Windows::Foundation::IInspectable,
    impl::consume_t<II2cDeviceProvider>,
    impl::require<II2cDeviceProvider, Windows::Foundation::IClosable>
{
    II2cDeviceProvider(std::nullptr_t = nullptr) noexcept {}
};

struct WINRT_EBO II2cProvider :
    Windows::Foundation::IInspectable,
    impl::consume_t<II2cProvider>
{
    II2cProvider(std::nullptr_t = nullptr) noexcept {}
};

struct WINRT_EBO IProviderI2cConnectionSettings :
    Windows::Foundation::IInspectable,
    impl::consume_t<IProviderI2cConnectionSettings>
{
    IProviderI2cConnectionSettings(std::nullptr_t = nullptr) noexcept {}
};

}
