﻿// C++/WinRT v1.0.180821.2

// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

#pragma once
#include "winrt/impl/Windows.Foundation.0.h"
#include "winrt/impl/Windows.Globalization.PhoneNumberFormatting.0.h"

WINRT_EXPORT namespace winrt::Windows::Globalization::PhoneNumberFormatting {

struct WINRT_EBO IPhoneNumberFormatter :
    Windows::Foundation::IInspectable,
    impl::consume_t<IPhoneNumberFormatter>
{
    IPhoneNumberFormatter(std::nullptr_t = nullptr) noexcept {}
};

struct WINRT_EBO IPhoneNumberFormatterStatics :
    Windows::Foundation::IInspectable,
    impl::consume_t<IPhoneNumberFormatterStatics>
{
    IPhoneNumberFormatterStatics(std::nullptr_t = nullptr) noexcept {}
};

struct WINRT_EBO IPhoneNumberInfo :
    Windows::Foundation::IInspectable,
    impl::consume_t<IPhoneNumberInfo>
{
    IPhoneNumberInfo(std::nullptr_t = nullptr) noexcept {}
};

struct WINRT_EBO IPhoneNumberInfoFactory :
    Windows::Foundation::IInspectable,
    impl::consume_t<IPhoneNumberInfoFactory>
{
    IPhoneNumberInfoFactory(std::nullptr_t = nullptr) noexcept {}
};

struct WINRT_EBO IPhoneNumberInfoStatics :
    Windows::Foundation::IInspectable,
    impl::consume_t<IPhoneNumberInfoStatics>
{
    IPhoneNumberInfoStatics(std::nullptr_t = nullptr) noexcept {}
};

}
