﻿// C++/WinRT v1.0.180821.2

// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

#pragma once
#include "winrt/impl/Windows.ApplicationModel.Payments.1.h"
#include "winrt/impl/Windows.ApplicationModel.Payments.Provider.1.h"

WINRT_EXPORT namespace winrt::Windows::ApplicationModel::Payments::Provider {

}

namespace winrt::impl {

}

WINRT_EXPORT namespace winrt::Windows::ApplicationModel::Payments::Provider {

struct WINRT_EBO PaymentAppCanMakePaymentTriggerDetails :
    Windows::ApplicationModel::Payments::Provider::IPaymentAppCanMakePaymentTriggerDetails
{
    PaymentAppCanMakePaymentTriggerDetails(std::nullptr_t) noexcept {}
};

struct WINRT_EBO PaymentAppManager :
    Windows::ApplicationModel::Payments::Provider::IPaymentAppManager
{
    PaymentAppManager(std::nullptr_t) noexcept {}
    static Windows::ApplicationModel::Payments::Provider::PaymentAppManager Current();
};

struct WINRT_EBO PaymentTransaction :
    Windows::ApplicationModel::Payments::Provider::IPaymentTransaction
{
    PaymentTransaction(std::nullptr_t) noexcept {}
    static Windows::Foundation::IAsyncOperation<Windows::ApplicationModel::Payments::Provider::PaymentTransaction> FromIdAsync(param::hstring const& id);
};

struct WINRT_EBO PaymentTransactionAcceptResult :
    Windows::ApplicationModel::Payments::Provider::IPaymentTransactionAcceptResult
{
    PaymentTransactionAcceptResult(std::nullptr_t) noexcept {}
};

}
