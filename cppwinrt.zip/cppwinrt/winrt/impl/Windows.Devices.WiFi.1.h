﻿// C++/WinRT v1.0.180821.2

// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

#pragma once
#include "winrt/impl/Windows.Networking.Connectivity.0.h"
#include "winrt/impl/Windows.Security.Credentials.0.h"
#include "winrt/impl/Windows.Devices.WiFi.0.h"

WINRT_EXPORT namespace winrt::Windows::Devices::WiFi {

struct WINRT_EBO IWiFiAdapter :
    Windows::Foundation::IInspectable,
    impl::consume_t<IWiFiAdapter>
{
    IWiFiAdapter(std::nullptr_t = nullptr) noexcept {}
};

struct WINRT_EBO IWiFiAdapter2 :
    Windows::Foundation::IInspectable,
    impl::consume_t<IWiFiAdapter2>
{
    IWiFiAdapter2(std::nullptr_t = nullptr) noexcept {}
};

struct WINRT_EBO IWiFiAdapterStatics :
    Windows::Foundation::IInspectable,
    impl::consume_t<IWiFiAdapterStatics>
{
    IWiFiAdapterStatics(std::nullptr_t = nullptr) noexcept {}
};

struct WINRT_EBO IWiFiAvailableNetwork :
    Windows::Foundation::IInspectable,
    impl::consume_t<IWiFiAvailableNetwork>
{
    IWiFiAvailableNetwork(std::nullptr_t = nullptr) noexcept {}
};

struct WINRT_EBO IWiFiConnectionResult :
    Windows::Foundation::IInspectable,
    impl::consume_t<IWiFiConnectionResult>
{
    IWiFiConnectionResult(std::nullptr_t = nullptr) noexcept {}
};

struct WINRT_EBO IWiFiNetworkReport :
    Windows::Foundation::IInspectable,
    impl::consume_t<IWiFiNetworkReport>
{
    IWiFiNetworkReport(std::nullptr_t = nullptr) noexcept {}
};

struct WINRT_EBO IWiFiWpsConfigurationResult :
    Windows::Foundation::IInspectable,
    impl::consume_t<IWiFiWpsConfigurationResult>
{
    IWiFiWpsConfigurationResult(std::nullptr_t = nullptr) noexcept {}
};

}
