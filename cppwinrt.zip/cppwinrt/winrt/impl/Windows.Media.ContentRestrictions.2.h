﻿// C++/WinRT v1.0.180821.2

// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

#pragma once
#include "winrt/impl/Windows.Storage.Streams.1.h"
#include "winrt/impl/Windows.Media.ContentRestrictions.1.h"

WINRT_EXPORT namespace winrt::Windows::Media::ContentRestrictions {

}

namespace winrt::impl {

}

WINRT_EXPORT namespace winrt::Windows::Media::ContentRestrictions {

struct WINRT_EBO ContentRestrictionsBrowsePolicy :
    Windows::Media::ContentRestrictions::IContentRestrictionsBrowsePolicy
{
    ContentRestrictionsBrowsePolicy(std::nullptr_t) noexcept {}
};

struct WINRT_EBO RatedContentDescription :
    Windows::Media::ContentRestrictions::IRatedContentDescription
{
    RatedContentDescription(std::nullptr_t) noexcept {}
    RatedContentDescription(param::hstring const& id, param::hstring const& title, Windows::Media::ContentRestrictions::RatedContentCategory const& category);
};

struct WINRT_EBO RatedContentRestrictions :
    Windows::Media::ContentRestrictions::IRatedContentRestrictions
{
    RatedContentRestrictions(std::nullptr_t) noexcept {}
    RatedContentRestrictions();
    RatedContentRestrictions(uint32_t maxAgeRating);
};

}
