﻿// C++/WinRT v1.0.180821.2

// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

#pragma once
#include "winrt/impl/Windows.Storage.Streams.1.h"
#include "winrt/impl/Windows.Devices.Printers.1.h"

WINRT_EXPORT namespace winrt::Windows::Devices::Printers {

}

namespace winrt::impl {

}

WINRT_EXPORT namespace winrt::Windows::Devices::Printers {

struct WINRT_EBO Print3DDevice :
    Windows::Devices::Printers::IPrint3DDevice
{
    Print3DDevice(std::nullptr_t) noexcept {}
    static Windows::Foundation::IAsyncOperation<Windows::Devices::Printers::Print3DDevice> FromIdAsync(param::hstring const& deviceId);
    static hstring GetDeviceSelector();
};

struct WINRT_EBO PrintSchema :
    Windows::Devices::Printers::IPrintSchema
{
    PrintSchema(std::nullptr_t) noexcept {}
};

}
